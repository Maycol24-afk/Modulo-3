/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blibliotecavirtual;

import clases.Biblioteca;
import clases.Libro;
import java.util.List;
import java.util.Scanner;

/**
 *
 *  @author DELL GAMING
 */
public class BlibliotecaVirtual {

  
    public static void main(String[] args) {
        
        Biblioteca biblioteca = new Biblioteca();
        Scanner scanner = new Scanner(System.in);

        // Agregar libros a la biblioteca
        biblioteca.agregarLibro(new Libro("El Hobbit", "J.R.R. Tolkien", 1937, "Fantasia"));
        biblioteca.agregarLibro(new Libro("Matar a un ruiseñor", "Harper Lee", 1960, "Ficcion historica"));
        biblioteca.agregarLibro(new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 1605, "Novela"));
        biblioteca.agregarLibro(new Libro("Orgullo y Prejuicio", "Jane Austen", 1813, "Novela romantica"));
        biblioteca.agregarLibro(new Libro("1984", "George Orwell", 1949, "Distopia"));

        int opcion;
        do {
            System.out.println("\nBiblioteca Virtual");
            System.out.println("1. Agregar libro");
            System.out.println("2. Buscar libro por titulo");
            System.out.println("3. Buscar libro por autor");
            System.out.println("4. Prestar libro");
            System.out.println("5. Devolver libro");
            System.out.println("6. Mostrar libros disponibles");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Titulo: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("Año de publicacion: ");
                    int anoPublicacion = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea
                    System.out.print("Genero: ");
                    String genero = scanner.nextLine();
                    biblioteca.agregarLibro(new Libro(titulo, autor, anoPublicacion, genero));
                    break;
                case 2:
                    System.out.print("Ingrese el titulo: ");
                    String tituloBusqueda = scanner.nextLine();
                    List<Libro> resultadosTitulo = biblioteca.buscarPorTitulo(tituloBusqueda);
                    if (resultadosTitulo.isEmpty()) {
                        System.out.println("No se encontraron libros con ese titulo.");
                    } else {
                        for (Libro libro : resultadosTitulo) {
                            System.out.println(libro);
                        }
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el autor: ");
                    String autorBusqueda = scanner.nextLine();
                    List<Libro> resultadosAutor = biblioteca.buscarPorAutor(autorBusqueda);
                    if (resultadosAutor.isEmpty()) {
                        System.out.println("No se encontraron libros de ese autor.");
                    } else {
                        for (Libro libro : resultadosAutor) {
                            System.out.println(libro);
                        }
                    }
                    break;
                case 4:
                    System.out.print("Ingrese el titulo del libro a prestar: ");
                    String tituloPrestar = scanner.nextLine();
                    if (biblioteca.prestarLibro(tituloPrestar)) {
                        System.out.println("El libro ha sido prestado.");
                    } else {
                        System.out.println("El libro no está disponible o no existe.");
                    }
                    break;
                case 5:
                    System.out.print("Ingrese el titulo del libro a devolver: ");
                    String tituloDevolver = scanner.nextLine();
                    if (biblioteca.devolverLibro(tituloDevolver)) {
                        System.out.println("El libro ha sido devuelto.");
                    } else {
                        System.out.println("El libro no está prestado o no existe.");
                    }
                    break;
                case 6:
                    System.out.println("Libros disponibles:");
                    biblioteca.mostrarLibrosDisponibles();
                    break;
                case 7:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        } while (opcion != 7);

        scanner.close();
    }
}
    
